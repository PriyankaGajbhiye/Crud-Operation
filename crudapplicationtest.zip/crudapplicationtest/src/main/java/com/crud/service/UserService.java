package com.crud.service;

import java.util.List;

import com.crud.model.LoginModel;
import com.crud.model.UserModel;

public interface UserService {
	
	public void saveUser(UserModel user);
	public UserModel editUserById(int id);
	public List<UserModel> getUsers();
	public void updateUser(UserModel user);
	public void deleteUser(int id);
	public List<UserModel> doLogin(LoginModel log);

}
