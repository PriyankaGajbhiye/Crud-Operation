package com.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crud.model.LoginModel;
import com.crud.model.UserModel;
import com.crud.service.UserService;
@CrossOrigin
@RestController
public class MainController {
	@Autowired
	private UserService userservice;
	@RequestMapping("test")
	public String testMe()
	{
		return "Welcome";
	}
	
	@PostMapping("saveuser")
	public String saveUser(@RequestBody UserModel user)
	{
		 userservice.saveUser(user);
		return "success";
	}
	
	@PostMapping("dologin")
	public String doLogin(@RequestBody LoginModel lm)
	{
		String logStatus=null;
		//System.out.println("Email "+lm.getPassword());
		List<UserModel> list=	userservice.doLogin(lm);
		if(list!=null) {
			logStatus = "success";
		}
		else
			logStatus="fail";
			
		return logStatus;
	}
	
	@GetMapping("userdetails")
	public List<UserModel> getUserDetails()
	{
		return userservice.getUsers();
	}
	
	@DeleteMapping("deleteuser/{id}")
	public String deleteUser(@PathVariable int id)
	{
		//System.out.println("id "+id);
		userservice.deleteUser(id);
		return "deleted";
	}
	
	@GetMapping("edituser/{id}")
	public UserModel getUserById(@PathVariable int id)
	{
		UserModel user = userservice.editUserById(id);
		return user;
	}
	@PostMapping("userupdate")
	public String updateUser(@RequestBody UserModel user)
	{
		userservice.updateUser(user);
		return "success";
	}

}
